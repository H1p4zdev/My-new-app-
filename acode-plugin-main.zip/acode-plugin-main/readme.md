# Acode plugin

Read acode plugin [documentation](https://docs.acode.app/docs/) to develop plugin for acode editor.

## Usage

Use this for debug build:

```
npm run dev
```

and this for production build:

```
npm run build
```

## How to parse/bundle scss file ?

You'll need to install one sass esbuild plugin and then just add that in `esbuild.config.mjs` at line 34
